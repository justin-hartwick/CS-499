"""
dashboard.py – Dash App (CS 340 Artifact)
Author: Justin Hartwick

Description:
    Dash dashboard that loads animal data from the AAC MongoDB database and
    displays a table view with a map showing the selected animal's location.

Engineering Notes:
    This version avoids hardcoding credentials directly in the source code.
    Runtime configuration is loaded from environment variables instead, which
    is a common best practice for maintainability and basic security hygiene.
"""

import os
import logging

from dash import Dash, html, dash_table
from dash.dependencies import Input, Output
import dash_leaflet as dl
import pandas as pd

from animal_shelter import AnimalShelter


# -------------------------------------------------
# Logging (configured at the application layer)
# -------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s [%(name)s] %(message)s"
)
logger = logging.getLogger(__name__)


# -------------------------------------------------
# MongoDB Connection Setup
# -------------------------------------------------
def get_mongo_settings() -> dict:
    """
    Load MongoDB settings from environment variables.

    Why environment variables:
        Credentials and configuration change between machines and environments.
        Keeping them out of source files reduces accidental exposure and makes
        the project easier to run in different setups without editing code.
    """
    settings = {
        "username": os.getenv("AAC_USER", ""),
        "password": os.getenv("AAC_PASS", ""),
        "host": os.getenv("AAC_HOST", "127.0.0.1"),
        "port": int(os.getenv("AAC_PORT", "27017")),
        "db_name": os.getenv("AAC_DB", "aac"),
        "collection_name": os.getenv("AAC_COLLECTION", "animals"),
    }
    return settings


def build_dataframe(shelter: AnimalShelter) -> pd.DataFrame:
    """
    Read data from MongoDB and convert to a DataFrame.

    A defensive approach is used here so the dashboard can still load even if:
        - the database is temporarily unreachable
        - the query returns no results
        - an unexpected schema appears
    """
    records = shelter.read({})
    df = pd.DataFrame.from_records(records)

    # The ObjectId field is not needed for dashboard display.
    if "_id" in df.columns:
        df.drop(columns=["_id"], inplace=True)

    return df


# -------------------------------------------------
# App Startup
# -------------------------------------------------
mongo_cfg = get_mongo_settings()

if not mongo_cfg["username"] or not mongo_cfg["password"]:
    raise RuntimeError(
        "Missing MongoDB credentials. Set AAC_USER and AAC_PASS environment variables."
    )

logger.info("Initializing MongoDB connection...")
shelter = AnimalShelter(
    mongo_cfg["username"],
    mongo_cfg["password"],
    mongo_cfg["host"],
    mongo_cfg["port"],
    mongo_cfg["db_name"],
    mongo_cfg["collection_name"]
)

logger.info("Loading data from MongoDB...")
df = build_dataframe(shelter)

# If the data load fails or returns no records, keep the app functional
# by displaying an empty table with a simple message.
if df.empty:
    logger.warning("No data returned from MongoDB query. Dashboard will load with empty table.")


# -------------------------------------------------
# Dash App Layout
# -------------------------------------------------
app = Dash(__name__)
app.title = "CS-340 Dashboard"

app.layout = html.Div([
    html.Center(html.B(html.H1("SNHU CS-340 Dashboard – Justin Hartwick"))),
    html.Hr(),

    html.Div(
        id="status-message",
        children="" if not df.empty else "No records returned from the database."
    ),

    dash_table.DataTable(
        id="datatable-id",
        columns=[{"name": col, "id": col} for col in df.columns] if not df.empty else [],
        data=df.to_dict("records"),
        page_size=10,
        sort_action="native",
        filter_action="native",
        row_selectable="single",
        selected_rows=[0],
        style_table={"overflowX": "auto"},
        style_cell={"textAlign": "left"},
        style_data={"whiteSpace": "normal", "height": "auto"},
    ),

    html.Br(),
    html.Hr(),

    html.Div(id="map-id", className="col s12 m6")
])


# -------------------------------------------------
# Callbacks
# -------------------------------------------------
@app.callback(
    Output("datatable-id", "style_data_conditional"),
    [Input("datatable-id", "selected_columns")]
)
def update_styles(selected_columns):
    # Highlight selected columns for readability.
    if not selected_columns:
        return []
    return [{"if": {"column_id": col}, "background_color": "#D2F3FF"} for col in selected_columns]


@app.callback(
    Output("map-id", "children"),
    [Input("datatable-id", "derived_virtual_data"),
     Input("datatable-id", "derived_virtual_selected_rows")]
)
def update_map(viewData, index):
    # If the table has no data, render a simple map view with a default location.
    if not viewData:
        default_lat, default_lon = 30.75, -97.48
        return [
            dl.Map(
                style={"width": "1000px", "height": "500px"},
                center=[default_lat, default_lon],
                zoom=4,
                children=[dl.TileLayer(id="base-layer-id")]
            )
        ]

    dff = pd.DataFrame.from_dict(viewData)
    row = index[0] if index else 0

    # Use safe defaults if location fields are missing or empty.
    lat = dff.iloc[row].get("location_lat") or 30.75
    lon = dff.iloc[row].get("location_long") or -97.48
    breed = dff.iloc[row].get("breed", "Unknown")
    name = dff.iloc[row].get("name", "Unnamed")

    marker_msg = f"{name} ({breed})"
    if lat == 30.75 and lon == -97.48:
        marker_msg += " (location unknown)"

    return [
        dl.Map(
            style={"width": "1000px", "height": "500px"},
            center=[lat, lon],
            zoom=10,
            children=[
                dl.TileLayer(id="base-layer-id"),
                dl.Marker(
                    position=[lat, lon],
                    children=[
                        dl.Tooltip(breed),
                        dl.Popup([
                            html.H1("Animal"),
                            html.P(marker_msg)
                        ])
                    ]
                )
            ]
        )
    ]


# -------------------------------------------------
# Run the app locally
# -------------------------------------------------
if __name__ == "__main__":
    # debug=True is helpful during development; it can be disabled for a more
    # production-like run once behavior is verified.
    app.run(debug=True)
