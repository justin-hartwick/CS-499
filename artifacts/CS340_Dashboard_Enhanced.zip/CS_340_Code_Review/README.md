# Grazioso Salvare Dashboard

## Overview
This project is a Dash-based dashboard developed for SNHU CS 340. It connects to
a MongoDB database containing AAC animal shelter records and provides a table
and map-based view of animal data to support rescue analysis.

## Key Components
- **animal_shelter.py**  
  Provides a reusable CRUD interface for MongoDB operations.

- **dashboard.py**  
  Dash application that loads data from MongoDB and presents it in a searchable
  table with an interactive map.

## Enhancements
The project was refined to improve maintainability and reliability:
- Database access logic was strengthened with clearer validation and structured logging.
- Runtime configuration was externalized using environment variables instead of
  hardcoded credentials.
- Error handling was made more consistent to prevent UI failures during database issues.

## Running the Application
Set the following environment variables before running the dashboard:
- `AAC_USER`
- `AAC_PASS`

Then run:
```bash
python dashboard.py

