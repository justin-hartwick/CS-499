"""
CS 340 – MongoDB CRUD Module
Author: Justin Hartwick

Description:
    Provides Create, Read, Update, and Delete operations for the AAC Animal
    Shelter database used by the Grazioso Salvare dashboard.

Enhancement Notes:
    The functionality of this module remains the same, but the implementation
    has been refined to improve maintainability, reliability, and overall code
    quality. These changes reflect standard software engineering practices
    commonly used in production applications.
"""

# -------------------------------------------------
# Imports
# -------------------------------------------------
import logging
from typing import Any, Dict, List, Optional

from pymongo import MongoClient
from pymongo.errors import PyMongoError

# Use module-level logging. Configuration is intentionally left to the
# application layer so logging behavior can be adjusted without changing
# this module.
logger = logging.getLogger(__name__)


class AnimalShelter:
    """
    CRUD operations for the AAC Animal Shelter database.

    This class acts as a data-access layer that isolates MongoDB logic from
    the dashboard interface. Keeping database operations separate from the
    UI improves readability, maintainability, and long-term extensibility.
    """

    def __init__(
        self,
        username: str,
        password: str,
        host: str = "127.0.0.1",
        port: int = 27017,
        db_name: str = "aac",
        collection_name: str = "animals",
        **client_kwargs: Any
    ) -> None:
        """
        Initialize the MongoDB connection.

        Credential validation is performed here so configuration issues are
        detected early rather than during later CRUD operations.

        A ping is issued immediately after connection setup to ensure the
        database is reachable at startup.
        """
        if not username or not password:
            raise ValueError("Username and password are required for MongoDB connection.")

        # Build the MongoDB connection URI.
        # The authentication source must match the AAC database.
        uri = f"mongodb://{username}:{password}@{host}:{port}/{db_name}?authSource=aac"

        # Fail quickly if the database is unreachable.
        client_kwargs.setdefault("serverSelectionTimeoutMS", 5000)

        try:
            self._client = MongoClient(uri, **client_kwargs)
            self._db = self._client[db_name]
            self._col = self._db[collection_name]

            # Force an immediate connectivity check.
            self._client.admin.command("ping")
            logger.info("Connected to MongoDB successfully.")
        except PyMongoError as e:
            # Log the exception details while raising a clean error for callers.
            logger.exception("MongoDB connection failed.")
            raise ConnectionError(f"MongoDB connection failed: {e}") from e

    # -------------------------------------------------
    # Create
    # -------------------------------------------------
    def create(self, data: Dict[str, Any]) -> bool:
        """
        Insert a single document into the collection.

        Returns:
            True if the insert is acknowledged by MongoDB, otherwise False.
        """
        if not data or not isinstance(data, dict):
            raise ValueError("Data must be a non-empty dictionary.")

        try:
            result = self._col.insert_one(data)
            return bool(result.acknowledged)
        except PyMongoError:
            logger.exception("Create operation failed.")
            return False

    # -------------------------------------------------
    # Read
    # -------------------------------------------------
    def read(
        self,
        query: Dict[str, Any],
        projection: Optional[Dict[str, Any]] = None,
        limit: int = 0
    ) -> List[Dict[str, Any]]:
        """
        Retrieve documents that match the query.

        Args:
            query: MongoDB query dictionary.
            projection: Optional field selection for returned documents.
            limit: Optional maximum number of documents to return.

        Returns:
            A list of matching documents.
        """
        if not isinstance(query, dict):
            raise ValueError("Query must be a dictionary.")
        if limit < 0:
            raise ValueError("Limit cannot be negative.")

        try:
            cursor = self._col.find(query, projection)
            if limit > 0:
                cursor = cursor.limit(limit)
            return list(cursor)
        except PyMongoError:
            logger.exception("Read operation failed.")
            return []

    # -------------------------------------------------
    # Update
    # -------------------------------------------------
    def update(self, query: Dict[str, Any], update_data: Dict[str, Any]) -> int:
        """
        Update all documents matching the query.

        Returns:
            The number of documents modified.
        """
        if not query or not isinstance(query, dict):
            raise ValueError("Query must be a non-empty dictionary.")
        if not update_data or not isinstance(update_data, dict):
            raise ValueError("Update data must be a non-empty dictionary.")

        try:
            result = self._col.update_many(query, {"$set": update_data})
            return int(result.modified_count)
        except PyMongoError:
            logger.exception("Update operation failed.")
            return 0

    # -------------------------------------------------
    # Delete
    # -------------------------------------------------
    def delete(self, query: Dict[str, Any]) -> int:
        """
        Delete all documents matching the query.

        Returns:
            The number of documents deleted.
        """
        if not query or not isinstance(query, dict):
            raise ValueError("Delete query must be a non-empty dictionary.")

        try:
            result = self._col.delete_many(query)
            return int(result.deleted_count)
        except PyMongoError:
            logger.exception("Delete operation failed.")
            return 0

    # -------------------------------------------------
    # Ping
    # -------------------------------------------------
    def ping(self) -> Dict[str, Any]:
        """
        Verify connectivity to the MongoDB server.

        Returns:
            A dictionary response if successful, otherwise an empty dictionary.
        """
        try:
            return dict(self._client.admin.command("ping"))
        except PyMongoError:
            logger.exception("Ping operation failed.")
            return {}
